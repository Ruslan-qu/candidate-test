<?php

declare(strict_types=1);

namespace JMS\Serializer\Exception;

class UnsupportedFormatException extends InvalidArgumentException
{
}
