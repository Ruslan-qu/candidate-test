<?php

declare(strict_types=1);

namespace JMS\Serializer\ContextFactory;

/**
 * @deprecated
 */
abstract class CallableContextFactory
{
}
