Event System
============

This document was moved to the standalone library, please see
`<http://jmsyst.com/libs/serializer/master/event_system>`_.